# Treadmill Rush 3D

A first-person 3D endless runner with **15 stages**. Each stage is 100 meters; reach 1,500 meters to win. The speed and obstacle pace increase as you progress.

## Play locally
Open `index.html` in a browser with an internet connection (Three.js loads from a CDN).

## Upload to GitHub Pages
1. Create a new repository on GitHub.
2. Upload `index.html` and this `README.md`.
3. Open **Settings → Pages**.
4. Choose **Deploy from a branch**, select `main` and `/(root)`, then save.
5. Wait for the Pages link to appear and open it.

## Controls
- **A / D** or **Left / Right arrows**: change lanes
- **Space / W / Up arrow**: jump
- **S / Down arrow**: slide
- **Esc**: pause

Choose a character color and trail, collect coins, and dodge blocks, barriers, and walls. Reach Stage 15 to win.
